SELECT Titolo, AnnoPubblicazione, CopieDisponibili
FROM Libro
WHERE CopieDisponibili >= 3
ORDER BY AnnoPubblicazione DESC;


SELECT UtenteID, Nome, Cognome, COUNT(*) AS NumeroPrestiti
FROM Prestito
JOIN Utente ON Prestito.UtenteID = Utente.IDUtente
GROUP BY UtenteID, Nome, Cognome
ORDER BY NumeroPrestiti DESC;






SELECT TOP 1 LibroISBN, COUNT(*) AS NumeroPrestiti
FROM Prestito
GROUP BY LibroISBN
ORDER BY NumeroPrestiti DESC;




SELECT ResponsabileBibliotecaID, Dipendente.Nome, Dipendente.Cognome, COUNT(*) AS NumeroPrestiti
FROM Prestito
JOIN Biblioteca ON Prestito.DipendenteCheGestisceIlPrestito = Biblioteca.Nome
JOIN Dipendente ON Biblioteca.ResponsabileBibliotecaID = Dipendente.IDDipendente
GROUP BY ResponsabileBibliotecaID, Dipendente.Nome, Dipendente.Cognome;






SELECT AVG(DATEDIFF(DataEffettivaRestituzione, DataPrestito)) AS MediaGiorniRestituzione
FROM Prestito;



SELECT TOP 1 Genere, COUNT(*) AS NumeroPrestiti
FROM Prestito
JOIN Libro ON Prestito.LibroISBN = Libro.ISBN
JOIN Utente ON Prestito.UtenteID = Utente.IDUtente
WHERE YEAR(Utente.DataNascita) > 1990
GROUP BY Genere
ORDER BY NumeroPrestiti DESC;




SELECT MONTH(DataPrestito) AS Mese, COUNT(*) AS NumeroPrestiti
FROM Prestito
WHERE YEAR(DataPrestito) = 2023
GROUP BY MONTH(DataPrestito)
ORDER BY Mese;




SELECT Ruolo, COUNT(*) AS NumeroDipendenti
FROM Dipendente
GROUP BY Ruolo
ORDER BY NumeroDipendenti DESC;



SELECT COUNT(*) AS NumeroPrestiti
FROM Prestito
JOIN Utente ON Prestito.UtenteID = Utente.IDUtente
WHERE YEAR(GETDATE()) - YEAR(Utente.DataNascita) BETWEEN 25 AND 40;




SELECT TOP 1 Titolo, Autore, AnnoPubblicazione
FROM Libro
ORDER BY AnnoPubblicazione;
