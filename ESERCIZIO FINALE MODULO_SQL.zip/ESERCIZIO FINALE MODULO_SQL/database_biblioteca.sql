create database Biblioteca;

use Biblioteca;

create table Libro (
ISBN VARCHAR(13),
    Titolo VARCHAR(255),
    Autore VARCHAR(255),
    AnnoPubblicazione YEAR,
    CopieDisponibili INT,
    Genere VARCHAR(50),
    Editore VARCHAR(100),
    Lingua VARCHAR(50),
    PRIMARY KEY (ISBN)
);

CREATE TABLE Utente (
    IDUtente INT,
    Nome VARCHAR(50),
    Cognome VARCHAR(50),
    DataNascita DATE,
    Indirizzo VARCHAR(255),
    Email VARCHAR(100),
    NumeroDiTelefono VARCHAR(15), 
    Professione VARCHAR(255),
    PRIMARY KEY (IDUtente)
);

CREATE TABLE Prestito (
    IDPrestito INT,
    DataPrestito DATE,
    DataScadenza DATE,
    DataEffettivaRestituzione DATE,
    StatoConsegna VARCHAR(20),
    LibroISBN VARCHAR(13),
    DipendenteCheGestisceIlPrestito VARCHAR(255),
    UtenteID INT,
    PRIMARY KEY (IDPrestito),
    CONSTRAINT FK_LibroISBN_Prestito_Libro FOREIGN KEY (LibroISBN) REFERENCES Libro(ISBN),
    CONSTRAINT FK_UtenteID_Prestito_Utente FOREIGN KEY (UtenteID) REFERENCES Utente(IDUtente)
);

CREATE TABLE Dipendente (
    IDDipendente INT,
    Nome VARCHAR(50),
    Cognome VARCHAR(50),
    Ruolo VARCHAR(50),
    Email VARCHAR(100),
    NumeroDiTelefono VARCHAR(15),
    DatadiNascita DATE,
    PRIMARY KEY (IDDipendente)
);

CREATE TABLE Biblioteca (
    PartitaIVA INT , 
    Nome VARCHAR(100),
    Indirizzo VARCHAR(255),
    OrarioDiAperturaEChiusura VARCHAR(100), 
    NumeroDiTelefono VARCHAR(15), 
    SitoWeb VARCHAR(255),
    ResponsabileBibliotecaID INT,
    PRIMARY KEY (PartitaIVA),
    CONSTRAINT FK_RespondabileBibliotecaID_Biblioteca_Dipendente FOREIGN KEY (ResponsabileBibliotecaID) REFERENCES Dipendente(IDDipendente) 
);

INSERT INTO Libro (ISBN, Titolo, Autore, AnnoPubblicazione, CopieDisponibili, Genere, Editore, Lingua)
VALUES
('456312489', 'Harry Potter e la camera dei segreti', 'JK Rowling', 2002, 4, 'Fantasy', 'Mondadori', 'Italiano'),
('213215684', 'Il vecchio e il mare', 'Ernest Hemingway', 1952, 2, 'Narrativa', 'Cairo editore', 'Italiano'),
('879653214', 'Il trono di spade lo scontro dei Re', 'George R R Martin', 1998, 1, 'Fantasy', 'Albatros editore', 'Italiano'),
('214587965', 'Oceano mare', 'Alessandro Baricco', 1993, 5, 'Romanzo breve', 'Feltrinelli', 'Italiano'),
('563245632', 'Uno nessuno centomila', 'Luigi Pirandello', 1926, 4, 'Romanzo', 'Einaudi', 'Italiano');

INSERT INTO Utente (IDUtente, Nome, Cognome, DataNascita, Indirizzo, Email, NumeroDiTelefono, Professione)
VALUES
(48578, 'Ugo', 'Fantozzi', '1940-01-01', 'Via della sfiga', 'fantozzi23@pec.it', '345896587', 'Ragioniere'),
(96145, 'Tizio', 'Qualsiasi', '1944-02-03', 'Via Roma', 'tizio@gmail.com', '3465874855', 'Agente'),
(78912, 'Caio', 'Qualunque', '1966-04-05', 'Via della Repubblica', 'caio@libero.it', '388965874', 'Sindaco'),
(87961, 'Sempronio', 'Rossi', '1975-05-05', 'Via della libertà', 'sempronio@aruba.it', '3456987456', 'Architetto'),
(11278, 'Mario', 'Verdi', '1998-02-12', NULL, 'marioverdi@tim.it', '3458745874', 'Studente');

INSERT INTO Prestito (IDPrestito, DataPrestito, DataScadenza, DataEffettivaRestituzione, StatoConsegna, LibroISBN, DipendenteCheGestisceIlPrestito, UtenteID)
VALUES
(100, '2023-05-27', '2023-06-27', '2023-07-15', 'Integro', '456312489', 'Pinco Pallino', 48578),
(252, '2022-04-25', '2022-05-25', '2022-05-25', 'Rovinato','213215684', 'Mario Rossi', 96145),
(456, '2023-07-01', '2023-08-01', '2023-08-01', 'Integro', '879653214', 'Viola Marrone', 78912),
(879, '2021-01-25', '2021-02-25', '2021-02-25', 'Integro', '214587965', 'Giuseppe Garibaldi', 87961),
(120, '2020-03-01', '2020-04-01', '2020-03-30', 'Rovinato', '563245632', 'Antonio Napoleone', 11278);

INSERT INTO Dipendente (IDDipendente, Nome, Cognome, Ruolo, Email, NumeroDiTelefono, DatadiNascita)
VALUES
(8965, 'Antonio', 'Mazzini', 'Amministrazione', 'mazzinibib@gmail.com', '346859657', '1990-04-24'),
(7865, 'Bar', 'Man', 'Addetto pulizie', 'barbib@outlook.it', '354878965', '1989-01-28'),
(4569, 'Vita', 'Queen', 'Addetta manutenzione', 'vitabibl@libero.it', '32456987', '1992-07-28'),
(2356, 'Giuseppe', 'White', 'Amministrazione', 'peppebibl@gmail.com', '34658745', '1990-01-29'),
(7896, 'Arcibaldo', 'Garibaldi', 'Amministrazione', 'arcibib@libero.it', '354789654', '1965-01-25');

INSERT INTO Biblioteca (PartitaIVA, Nome, Indirizzo, OrarioDiAperturaEChiusura, NumeroDiTelefono, SitoWeb, ResponsabileBibliotecaID)
VALUES
(123456896, 'Biblioteca civica', 'Via della cultura', '09:00 - 18:00', '345896587','www.vienialeggere.it', 7896);

